package com.example.pokimon;

public class pokimon {


    public static Object add;
    private String name ;
     private int attack;
      private int defende ;
        private int total;

    public pokimon(String name, int mpo1, int mpo, int i, int i1) {

    }

    public static void add(pokimon p1) {
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefende() {
        return defende;
    }

    public void setDefende(int defende) {
        this.defende = defende;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
